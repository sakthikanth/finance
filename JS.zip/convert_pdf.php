<?php

echo $_REQUEST['html'];
